var searchData=
[
  ['max_5fangle',['max_angle',['../struct_laser_config.html#a2d09a717415770110787788127ad6b14',1,'LaserConfig']]],
  ['max_5frange',['max_range',['../struct_laser_config.html#a977dcea9a68dc9dd21113fd0eff24c9c',1,'LaserConfig']]],
  ['max_5fscan_5fnodes',['MAX_SCAN_NODES',['../classydlidar_1_1_y_dlidar_driver.html#a13a4f2dc4067b43794b2c47c06d5d27aa3db6fc46c7ce55cdf3a968b70e96374a',1,'ydlidar::YDlidarDriver']]],
  ['millisecondtimer',['MillisecondTimer',['../classserial_1_1_millisecond_timer.html',1,'serial']]],
  ['min_5fangle',['min_angle',['../struct_laser_config.html#a0b68f6041dc05310626ef221d4cc2db9',1,'LaserConfig']]],
  ['min_5frange',['min_range',['../struct_laser_config.html#a262652da08f505f112be9e017fb43a43',1,'LaserConfig']]],
  ['model',['model',['../structdevice__info.html#a3c491b342ed11af3c70358e7e8f6c935',1,'device_info']]]
];
